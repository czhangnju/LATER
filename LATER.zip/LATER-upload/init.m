function [H, P] = init(X, index, param)
%   min   |Xe^i - P^i*H*Se^i|
%   s.t.  Xi = Pi*H + E1^i, H = H*Qt + E2, Xi=XiQi+E^i, Qi = Di, PiPi^T = I, ...
%
num_view = length(X);
[~, n] = size(X{1});
Xe = [];
for i=1:num_view
    POS = find(index(:,i)==1);
    Tep = zeros(n, length(POS));
    for j=1:length(POS)
        Tep(POS(j),j) = 1;
    end
    W{i} = Tep;
    Xe{i} = X{i}*W{i};
end
n = size(X{1},2);

dim  = param.dim;
H = rand(dim, n);

MAX_iter = 30;

for iter = 1:MAX_iter
    % P step
    for i=1:num_view
        [U1,~,V1] = svd(Xe{i}*(H*W{i})','econ');
        P{i} = U1*V1';
       clear Temp U1 V1;
    end
     
    % H
    H = UpdateH(H, Xe, W, P);
    
    
%      thrsh = 1e-6;
%     if(norm(RR, inf)<thrsh)
%         break;
%     end
    
    
end

end
