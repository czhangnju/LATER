function [H] = UpdateH(H, X, W, P)

   [l,k] = size(H);
  
   manifold = elliptopefactory(l,k);
   problem.M = manifold;
    
    % Define the problem cost function and its gradient.
    problem.cost = @(x) LCost(x, X, W, P);
    problem.grad = @(x) LGrad(x, X, W, P);

    % Numerically check gradient consistency.
    %checkgradient(problem);

    param.tooloptions.maxiter = 20;
    param.tooloptions.gradnorm = 1e-5;
    options = param.tooloptions;
   % [x xcost info] = trustregions(problem,L,options);
     [x, ~,~] = steepestdescent(problem,H,options);
    H = x;
    
   % H =  NormalizeFea(H,1);
end

function cost = LCost(L, X, W, P)
    cost = 0;
    for i=1:length(W)
        cost = cost + trace( L*W{i}*(W{i}'*L'*P{i}' - X{i}')*P{i});
    end
end
function grad = LGrad(L,X, W, P)
    grad = 0;
    for i=1:length(W)
        grad = grad + P{i}'*(P{i}*L*W{i}-X{i})*W{i}';
    end
end