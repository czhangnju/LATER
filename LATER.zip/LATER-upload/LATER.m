function [G] = LATER(X, index, param)
%   min    |D|_{t*} + lamba1*|E1|_{2,1} 
%           + lambda2*|E2|_{2,1} + lambda3*|E3|_{2,1}
%   s.t.  Xi = Pi*H + E1^i (Z1), H = H*Qt + E2 (Z2), Xi=XiQi+E3^i (Z4), Qi = Di(Z5), PiPi^T = I, ...
%
num_view = length(X);
dk=[]; POS = []; POS2=[];
for i=1:num_view
    X{i} = X{i}./repmat(sqrt(sum(X{i}.^2,1)),size(X{i},1),1);  %normalized
    dk{i} = size(X{i},1);
    POS{i} = find(index(:,i)==1);
    POS2{i} =  find(index(:,i)==0);
    X{i}(:,POS2{i}) = 0;
end
Xc = X;
[~, n] = size(X{1});

lambda1  =  param.lambda1;
lambda2  =  param.lambda2;
lambda3  =  param.lambda3;
dim      =  param.dim;

E1 = cell(1,num_view);
for iv = 1:num_view
    E1{iv} = zeros(dk{iv}, n);
    Q{iv} = zeros(n);
end
S =  zeros(n); 
Q{num_view+1} = S;
D = Q;
E2 = zeros(dim,n);
E3 = E1;

Z1 = E1; 
Z2 = zeros(dim, n);
Z4 = E3;
Z5 = Q;
Z5{num_view+1} = S;

MAX_iter = 30;

tt = 1;
rho1 = tt;
rho2 = tt;
rho4 = tt;
rho5 = tt;
theta = 1.3;
[H, P] = init(X, index, param);


for iter = 1:MAX_iter
     if mod(iter, 20)==0
      fprintf('%d..',iter);
     end
    % X step
    for i=1:num_view
        TempA = P{i}*H+E1{i}-Z1{i}/rho1+(E3{i}-Z4{i}/rho4)*(eye(n)-Q{i})';
        TempB = eye(n)+(eye(n)-Q{i})*(eye(n)-Q{i})';
        Temp = TempA/TempB;
        Xci = Xc{i};
        Temp(:,POS{i}) = Xci(:,POS{i});
        X{i} = Temp;
        clear TempA TempB Temp Xci;
    end
    
        % P step
    for i=1:num_view
        Temp = X{i} - E1{i} + Z1{i}/rho1;
        [U1,~,V1] = svd(Temp*H','econ');
        P{i} = U1*V1';
       clear Temp U1 V1;
    end
    
    % H step
    HA = 0; HB = 0; HC = 0;
    for i=1:num_view
        HA = HA + rho1*P{i}'*P{i};
        HC = HC + rho1*P{i}'*(X{i}-E1{i}+Z1{i}/rho1);
    end
    HC = HC + rho2*(E2-Z2/rho2)*(eye(n)-Q{num_view+1})';
    HB = rho2*(eye(n)-Q{num_view+1})*(eye(n)-Q{num_view+1})';
    H = lyap(HA,HB,-HC);
    clear HA HB HC;
   
    
   % E step
    for i=1:num_view
        E1{i} = prox_l21(X{i}-P{i}*H + Z1{i}/rho1, lambda1/rho1);
        E3{i} = prox_l21(X{i}-X{i}*Q{i} + Z4{i}/rho4, lambda3/rho4);
    end
     E2 = prox_l21(H - H*Q{num_view+1} + Z2/rho2,lambda2/rho2);
    
    
    % D step
    Q_tensor = cat(3, Q{:,:});
    Z5_tensor = cat(3, Z5{:,:});
    Qv = Q_tensor(:);
    Z5v = Z5_tensor(:);
    [Dv, ~] = wshrinkObj(Qv + 1/rho5*Z5v, 1/rho5, [n, n, num_view+1], 0,3);
    D_tensor = reshape(Dv, [n, n, num_view+1]);  
    for i=1:num_view+1
        D{i} = D_tensor(:,:,i);
    end
    clear i
    
    % Q step
    for i = 1:num_view
        tQ1 = rho4*X{i}'*X{i} + rho5*eye(n);
        tQ2 = rho4*X{i}'*(X{i}-E3{i}+Z4{i}/rho4)+ rho5*D{i} - Z5{i};
        Q{i} = tQ1\tQ2;
    end
    tQ1 = rho2*H'*H + rho5*eye(n);
    tQ2 = rho2*H'*(H- E2+Z2/rho2)+ rho5*D{num_view+1} - Z5{num_view+1};
    Q{num_view+1} = tQ1\tQ2;
    clear tQ1 tQ2
    clear i
    
    %
    RR=[];RR2=[]; RR3=[];
    for i=1:num_view
        res = X{i} - P{i}*H - E1{i};
        res2 = X{i} - X{i}*Q{i} - E3{i};
        res3 = Q{i} - D{i};
        Z1{i} = Z1{i} + rho1*res;
        Z4{i} = Z4{i} + rho4*res2;
        Z5{i} = Z5{i} + rho5*res3;
        RR=[RR; res];
        RR2=[RR2; res2];
        RR3=[RR3; res3];
    end
    RR3=[RR3; Q{num_view+1} - D{num_view+1}];
    Z5{num_view+1} = Z5{num_view+1} + rho5*(Q{num_view+1} - D{num_view+1});
    Z2 = Z2 + rho2*(H-H*Q{num_view+1}-E2);
 
    rho1 = min(1e6, theta*rho1);
    rho2 = min(1e6, theta*rho2);
    rho4 = min(1e6, theta*rho4);
    rho5 = min(1e6, theta*rho5);
    
    thrsh = 1e-6;
    if(norm(RR, inf)<thrsh && norm(RR2, inf)<thrsh && norm(RR3, inf)<thrsh && norm(H-H*Q{num_view+1}-E2,inf)<thrsh )
        break;
    end
    
    
end

 KK=0;
 for i=1:num_view+1
    KK = KK + (abs(Q{i})+(abs(Q{i}))');
end
G = KK/2/(num_view+1);     
end
