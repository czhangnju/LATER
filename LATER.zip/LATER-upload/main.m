clear; close all;

addpath ./ClusteringMeasure
addpath ./twist
addpath(genpath('lib/manopt'));
path = './data/';


load ./data/MSRC.mat;
name = 'MSRC';
percentDel = 0.1;  %% missing data rate
Datafold= [path,'Index_',name,'_percentDel_',num2str(percentDel),'.mat'];
load(Datafold)
param.lambda1 = 1;
param.lambda2 = .01;
param.lambda3 = .1;
param.dim = 50; 

cls_num = numel(unique(gt));
%% BBCSport
fPCA = 0;
result = []; perf = [];
for kk = 1:length(Index)  %% total 10 different missing data indices
    Xc = X;
    ind = Index{kk};
    for i=1:length(Xc)   %% set the missing features to 0
        Xci = Xc{i};
        indi = ind(:,i);
        pos = find(indi==0);
        Xci(:,pos)=0; 
        Xc{i} = Xci;
    end
   
[G] = LATER(Xc, ind, param);  %% LATER algorithm
[Clus] = SpectralClustering(G, cls_num);

[~,NMI,~] = compute_nmi(Clus, gt);
ACC = Accuracy(Clus, gt);
[f, ~,~]=compute_f(gt, Clus);
[ARI,~,~]=RandIndex(gt, Clus);
[~,~, PUR] = purity(gt,Clus);
pp = [NMI ACC f ARI PUR];
perf = [perf; pp];
fprintf("Repeat: %d, NMI, ACC, f, ARI, Purity: %.4f, %.4f, %.4f, %.4f, %.4f \n",kk, NMI, ACC, f, ARI,PUR );
end
mean(perf)

